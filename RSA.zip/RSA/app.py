from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# RSA imports
from CreateKey import getPQ, getE, getD
from encode import encode as rsa_encode, getPublicKey
from decode import decode as rsa_decode, getPrivateKey

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    public_key = db.Column(db.Text, nullable=True)
    private_key = db.Column(db.Text, nullable=True)

# Message model
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    encrypted_message = db.Column(db.Text, nullable=False)
    original_message = db.Column(db.Text, nullable=True)  # Store original message

# Utility functions for RSA integration
def generate_keys():
    p, q = getPQ("Data/BigPrime.txt")
    n = p * q
    phi = (p - 1) * (q - 1)
    e = getE(phi)
    d = getD(e, phi)
    public_key = f"{n}\n{e}"
    private_key = f"{n}\n{d}"
    return public_key, private_key

def encode_message(plaintext, public_key):
    n, e = map(int, public_key.split('\n'))
    return rsa_encode(n, e, plaintext)  # File writing skipped

def decode_message(ciphertext, private_key):
    n, d = map(int, private_key.split('\n'))
    return rsa_decode(n, d, ciphertext.split(), 4)  # File writing skipped

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return redirect(url_for('register'))

        # Generate RSA keys
        public_key, private_key = generate_keys()

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_password, public_key=public_key, private_key=private_key)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password!', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in to access the dashboard.', 'warning')
        return redirect(url_for('login'))

    users = User.query.filter(User.id != session['user_id']).all()
    return render_template('dashboard.html', username=session.get('username'), users=users)

@app.route('/send_message', methods=['GET', 'POST'])
def send_message():
    if 'user_id' not in session:
        flash('Please log in to send messages.', 'warning')
        return redirect(url_for('login'))

    if request.method == 'POST':
        receiver_id = request.form['receiver_id']
        message = request.form['message']

        # Fetch receiver's public key
        receiver = User.query.get(receiver_id)
        if not receiver:
            flash('Recipient not found.', 'danger')
            return redirect(url_for('dashboard'))

        # Encrypt message using RSA
        encrypted_message = encode_message(message, receiver.public_key)

        new_message = Message(sender_id=session['user_id'], receiver_id=receiver_id, encrypted_message=encrypted_message, original_message=message)
        db.session.add(new_message)
        db.session.commit()

        flash(f'Message sent successfully! Encrypted message: {encrypted_message}', 'success')
        return redirect(url_for('send_message'))

    users = User.query.filter(User.id != session['user_id']).all()
    return render_template('send_message.html', users=users)

@app.route('/messages')
def messages():
    if 'user_id' not in session:
        flash('Please log in to view messages.', 'warning')
        return redirect(url_for('login'))

    received_messages = Message.query.filter_by(receiver_id=session['user_id']).all()
    decoded_messages = []

    for msg in received_messages:
        # Decode message using RSA
        user = User.query.get(session['user_id'])
        decoded_message = decode_message(msg.encrypted_message, user.private_key)
        decoded_messages.append({
            'original': msg.original_message,
            'encrypted': msg.encrypted_message,
            'decoded': decoded_message
        })

    return render_template('messages.html', messages=decoded_messages)

@app.route('/encode_decode', methods=['GET', 'POST'])
def encode_decode():
    if 'user_id' not in session:
        flash('Please log in to access the encode/decode feature.', 'warning')
        return redirect(url_for('login'))

    encoded_message = None
    decoded_message = None

    if request.method == 'POST':
        message = request.form['message']
        action = request.form['action']

        user = User.query.get(session['user_id'])

        if action == 'encode':
            # Encode message using RSA
            encoded_message = encode_message(message, user.public_key)
        elif action == 'decode':
            # Decode message using RSA
            decoded_message = decode_message(message, user.private_key)

    return render_template('encode_decode.html', encoded_message=encoded_message, decoded_message=decoded_message)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables if they don't exist
    app.run(debug=True)
